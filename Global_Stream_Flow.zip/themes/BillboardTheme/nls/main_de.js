// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/BillboardTheme/nls/strings":{_themeLabel:"Billboard-Design",_layout_default:"Standard-Layout",_layout_right:"Rechtes Layout",_localized:{}}});